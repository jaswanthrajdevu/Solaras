# SOLARA — Interactive Solar System

A premium educational Solar System experience built with **only HTML, CSS and vanilla JavaScript**.

## Included experiences
- Three.js 3D Solar System with CSS-orbit fallback, hover/tap previews, and camera focus
- Procedural planet surfaces, a subtle layered starfield, solar corona, selective atmospheric rims, and textured Saturn rings
- Reusable planet explorer with Overview, Structure, Atmosphere, and Moons sections
- Structured planet, layer, atmosphere, and moon data in `js/planet-data.js`
- Hover/focus planet information and click-to-explore behavior
- Reduced-motion support and keyboard-accessible planet-strip selection
- Detailed planet profiles
- Interactive internal-layer explorer
- Chronological missions and discoveries archive with combined agency, destination and category filters
- Structured mission and discovery records in `js/missions-data.js` with keyboard-selectable timeline details
- Planet comparison lab
- Solar quiz and planet-order puzzle
- Responsive layout and mobile-friendly tap interactions
- Optional lightweight sound feedback
- Dark, premium UI inspired by the visual direction of the supplied reference ZIP

## Run
Open `index.html` in a modern browser. Three.js is loaded from a CDN; when it or WebGL is unavailable, the CSS orbital model remains available.

No build step and no framework are required.
