const planets=window.SOLARA_PLANETS;
const missions=window.SOLARA_MISSIONS;
const planetStrip=document.getElementById('planetStrip');
Object.entries(planets).forEach(([name,p])=>{if(name==='Sun')return;const b=document.createElement('button');b.className='strip-card';b.innerHTML=`${name}<span>${p.tagline}</span>`;b.onclick=event=>{selectPlanet(name);if(event.detail===0)document.getElementById('previewExplore').focus()};b.onfocus=()=>setPlanetPreview(name);planetStrip.appendChild(b)});
let focusedPlanet='Earth';
let selectedPlanet='Earth';
let hasPlanetSelection=false;
const planetOrder=Object.keys(planets).filter(name=>name!=='Sun');
function setPlanetPreview(name){name=name||selectedPlanet;focusedPlanet=name;document.getElementById('previewName').textContent=name;document.getElementById('previewTagline').textContent=planets[name].tagline;document.getElementById('previewExplore').innerHTML=`Explore ${name} <span aria-hidden="true">→</span>`;document.getElementById('previewExplore').hidden=!hasPlanetSelection||name!==selectedPlanet;document.getElementById('planetIndex').textContent=name==='Sun'?'STAR / 08':`${String(planetOrder.indexOf(name)+1).padStart(2,'0')} / 08`;document.getElementById('solarStage').dataset.focusedPlanet=name}
let solarSystem=null;
function selectPlanet(name,focus=true){selectedPlanet=name;hasPlanetSelection=true;setPlanetPreview(name);if(solarSystem){if(focus)solarSystem.focusPlanet(name);document.getElementById('returnToSystem').hidden=false}}
const solarStage=document.getElementById('solarStage');
solarSystem=window.SOLARA_createSolarSystem({stage:solarStage,canvas:document.getElementById('solarCanvas'),onHover:name=>setPlanetPreview(name),onSelect:name=>selectPlanet(name,false),onError:error=>{console.error(error);const status=document.getElementById('solarFallbackStatus');status.textContent=error.message;status.hidden=false}});
if(solarSystem){solarStage.classList.add('is-3d');solarStage.querySelectorAll('.orbit-path,.sun').forEach(node=>node.setAttribute('aria-hidden','true'));solarStage.querySelectorAll('.planet-node').forEach(node=>node.tabIndex=-1)}
document.querySelectorAll('.planet-node').forEach(node=>{const name=node.dataset.planet;node.addEventListener('mouseenter',()=>setPlanetPreview(name));node.addEventListener('focus',()=>setPlanetPreview(name));node.addEventListener('click',event=>{selectPlanet(name);if(event.detail===0)document.getElementById('previewExplore').focus()})});
solarStage.addEventListener('mouseleave',()=>setPlanetPreview(selectedPlanet));
solarStage.addEventListener('focusout',event=>{if(!solarStage.contains(event.relatedTarget))setPlanetPreview(selectedPlanet)});
document.getElementById('previewExplore').addEventListener('click',()=>openPlanet(focusedPlanet));
const explorerTabs=document.getElementById('explorerTabs');
function switchExplorerTab(tabName,focus=false){const tab=[...explorerTabs.querySelectorAll('[role="tab"]')].find(item=>item.dataset.tab===tabName);if(!tab)return;explorerTabs.querySelectorAll('[role="tab"]').forEach(item=>{const active=item===tab;item.classList.toggle('active',active);item.setAttribute('aria-selected',String(active));item.tabIndex=active?0:-1;document.getElementById(item.getAttribute('aria-controls')).hidden=!active});if(focus)tab.focus()}
explorerTabs.addEventListener('click',event=>{const tab=event.target.closest('[role="tab"]');if(tab)switchExplorerTab(tab.dataset.tab)});
explorerTabs.addEventListener('keydown',event=>{const tabs=[...explorerTabs.querySelectorAll('[role="tab"]')];const current=tabs.indexOf(document.activeElement);let next=current;if(event.key==='ArrowRight')next=(current+1)%tabs.length;else if(event.key==='ArrowLeft')next=(current-1+tabs.length)%tabs.length;else if(event.key==='Home')next=0;else if(event.key==='End')next=tabs.length-1;else return;event.preventDefault();switchExplorerTab(tabs[next].dataset.tab,true)});
function pageMode(id){document.querySelectorAll('main>.page').forEach(p=>p.classList.remove('active','active-page'));document.getElementById(id).classList.add('active');if(id==='home')document.getElementById('home').classList.add('active-page');solarSystem?.setActive(id==='home');window.scrollTo({top:0,behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'})}
function openPlanet(name){const p=planets[name];selectedPlanet=name;setPlanetPreview(name);document.getElementById('detailName').textContent=name;document.getElementById('detailTagline').textContent=p.tagline;document.getElementById('detailDescription').textContent=p.description;document.getElementById('detailEyebrow').textContent=name==='Sun'?'STELLAR PROFILE':'PLANETARY PROFILE';const visual=document.getElementById('detailPlanet');visual.className='detail-planet '+name.toLowerCase()+'-large';document.getElementById('statGrid').innerHTML=Object.entries(p.facts).map(([k,v])=>`<div class="stat"><span>${k}</span><strong>${v}</strong></div>`).join('');document.getElementById('structurePlanetName').textContent=name;document.getElementById('atmospherePlanetName').textContent=name;document.getElementById('moonsPlanetName').textContent=name;renderStructure(name);renderAtmosphere(p);renderMoons(p);switchExplorerTab('overview');pageMode('planetDetail');document.getElementById('tab-overview').focus()}
const layerPalette=['#b8c2d9','#d77d59','#ed9c58','#ffd17a','#9bcde8'];
function renderStructure(name){const layers=planets[name].layers;const svg=document.getElementById('crossSection');const selector=document.getElementById('layerSelector');svg.replaceChildren();selector.replaceChildren();svg.setAttribute('viewBox','0 0 300 300');const title=document.createElementNS('http://www.w3.org/2000/svg','title');title.textContent=`${name} internal structure. Select a layer or region.`;svg.appendChild(title);const radiusStart=120;const radiusStep=layers.length===4?30:Math.min(34,90/layers.length);let selectedIndex=Math.max(0,layers.findIndex(layer=>layer.name.toLowerCase()==='crust'));function selectLayer(index){selectedIndex=index;svg.querySelectorAll('.structure-ring').forEach((ring,i)=>{ring.classList.toggle('selected',i===index);ring.classList.toggle('secondary',i!==index);ring.setAttribute('aria-pressed',String(i===index))});selector.querySelectorAll('button').forEach((button,i)=>{button.classList.toggle('active',i===index);button.setAttribute('aria-pressed',String(i===index))});renderLayerInfo(layers[index],index,layers.length)}layers.forEach((layer,index)=>{const ring=document.createElementNS('http://www.w3.org/2000/svg','circle');ring.setAttribute('cx','150');ring.setAttribute('cy','150');ring.setAttribute('r',String(radiusStart-index*radiusStep));ring.setAttribute('fill','none');ring.setAttribute('stroke',layerPalette[index%layerPalette.length]);ring.setAttribute('stroke-width',String(Math.max(radiusStep-3,13)));ring.setAttribute('role','button');ring.setAttribute('tabindex','0');ring.setAttribute('aria-label',`Select ${layer.name}`);ring.setAttribute('aria-pressed','false');ring.classList.add('structure-ring');ring.dataset.layerIndex=String(index);ring.addEventListener('click',()=>selectLayer(index));ring.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();selectLayer(index)}});svg.appendChild(ring);const button=document.createElement('button');button.type='button';button.textContent=layer.name;button.setAttribute('aria-pressed','false');button.addEventListener('click',()=>selectLayer(index));selector.appendChild(button)});selectLayer(selectedIndex)}
function renderLayerInfo(layer,index,total){const info=document.getElementById('layerInfo');info.replaceChildren();const eyebrow=document.createElement('p');eyebrow.className='eyebrow';eyebrow.textContent=`LAYER ${String(index+1).padStart(2,'0')} / ${String(total).padStart(2,'0')}`;const heading=document.createElement('h4');heading.textContent=layer.name;const description=document.createElement('p');description.className='layer-description';description.textContent=layer.description;const details=document.createElement('dl');[['Composition',layer.composition],['Temperature',layer.temperature],['Physical state',layer.state],['Depth',layer.depth]].forEach(([label,value])=>{const term=document.createElement('dt');term.textContent=label;const detail=document.createElement('dd');detail.textContent=value||'Not available in the current data.';details.append(term,detail)});info.append(eyebrow,heading,description,details)}
function renderAtmosphere(planet){const content=document.getElementById('atmosphereContent');content.replaceChildren();const atmosphere=planet.atmosphere;if(!atmosphere){content.textContent='Atmosphere information is not available in the current data.';return}const summary=document.createElement('p');summary.className='explorer-summary';summary.textContent=atmosphere.summary;const heading=document.createElement('h4');heading.textContent='Known components';const list=document.createElement('ul');list.className='composition-list';(atmosphere.composition||[]).forEach(item=>{const row=document.createElement('li');row.textContent=item;list.appendChild(row)});content.append(summary);if(list.childElementCount)content.append(heading,list);else content.append(emptyExplorerMessage('Composition details are not available in the current data.'))}
function renderMoons(planet){const content=document.getElementById('moonsContent');content.replaceChildren();const moons=planet.moons;if(!moons){content.textContent='Moon information is not available in the current data.';return}const count=document.createElement('p');count.className='moon-count';count.textContent=moons.count||'Count not provided';const summary=document.createElement('p');summary.className='explorer-summary';summary.textContent=moons.summary||'Moon details are not available in the current data.';content.append(count,summary);if(moons.notable?.length){const list=document.createElement('ul');list.className='moon-list';moons.notable.forEach(moon=>{const item=document.createElement('li');item.textContent=moon;list.appendChild(item)});content.appendChild(list)}else if(moons.count!=='0'&&moons.count!=='Not applicable')content.appendChild(emptyExplorerMessage('Notable moon details are not available in the current data.'))}
function emptyExplorerMessage(message){const empty=document.createElement('p');empty.className='explorer-empty';empty.textContent=message;return empty}
document.getElementById('backToSpace').onclick=()=>{selectedPlanet='Earth';hasPlanetSelection=false;setPlanetPreview('Earth');solarSystem?.returnToSystem();document.getElementById('returnToSystem').hidden=true;pageMode('home');document.getElementById('startExplore').focus()};document.getElementById('returnToSystem').onclick=()=>{selectedPlanet='Earth';hasPlanetSelection=false;setPlanetPreview('Earth');solarSystem?.returnToSystem();document.getElementById('returnToSystem').hidden=true};document.getElementById('startExplore').onclick=()=>document.getElementById('solarStage').scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'center'});document.getElementById('tourBtn').onclick=()=>openPlanet('Earth');
const menu=document.getElementById('mobileMenu');const menuToggle=document.getElementById('menuToggle');function setMobileMenuOpen(open){menu.classList.toggle('open',open);menu.setAttribute('aria-hidden',String(!open));menuToggle.setAttribute('aria-expanded',String(open));menuToggle.setAttribute('aria-label',open?'Close menu':'Open menu')}function nav(){document.querySelectorAll('a[href^="#"]').forEach(a=>a.addEventListener('click',e=>{const id=a.getAttribute('href').slice(1);if(['home','missions','lab','challenge'].includes(id)){e.preventDefault();pageMode(id);setMobileMenuOpen(false)}}))}nav();
const missionAgencyFilter=document.getElementById('missionAgencyFilter');
const missionTargetFilter=document.getElementById('missionTargetFilter');
const missionCategoryFilter=document.getElementById('missionCategoryFilter');
const missionTimeline=document.getElementById('missionTimeline');
const missionDetail=document.getElementById('missionDetail');
const missionResultCount=document.getElementById('missionResultCount');
let visibleMissions=[];
let selectedMissionId=null;

function createMissionElement(tag,className,text){
 const element=document.createElement(tag);
 if(className)element.className=className;
 if(text!==undefined)element.textContent=text;
 return element;
}

function renderMissionDetail(mission){
 missionDetail.replaceChildren();
 const header=createMissionElement('header','mission-detail-header');
 const headingBlock=createMissionElement('div','');
 const kind=createMissionElement('p','eyebrow',mission.category==='mission'?'MISSION PROFILE':'DISCOVERY NOTE');
 const title=createMissionElement('h3','',mission.name);
 headingBlock.append(kind,title);
 const year=createMissionElement('p','mission-detail-year',String(mission.year));
 header.append(headingBlock,year);

 const metadata=createMissionElement('dl','mission-detail-meta');
 [
  ['Year',String(mission.year)],
  ['Country',mission.country],
  ['Space agency',mission.agency],
  ['Target',mission.targetLabel],
  [mission.category==='mission'?'Mission type':'Finding type',mission.missionType]
 ].forEach(([label,value])=>{
  const term=createMissionElement('dt','',label);
  const detail=createMissionElement('dd','',value||'Not available in the current data.');
  metadata.append(term,detail);
 });
 if(mission.relatedMission){
  metadata.append(
   createMissionElement('dt','','Related mission'),
   createMissionElement('dd','',mission.relatedMission)
  );
 }

 const story=createMissionElement('div','mission-detail-story');
 [
  ['The story',mission.summary],
  ['Key achievement',mission.achievement],
  [mission.category==='mission'?'Outcome':'Why it matters',mission.outcome]
 ].forEach(([label,value],index)=>{
  const section=createMissionElement('section',`mission-detail-point${index===0?' mission-detail-lead':''}`);
  section.append(createMissionElement('p','eyebrow',label),createMissionElement('p','',value||'Not available in the current data.'));
  story.appendChild(section);
 });
 missionDetail.append(header,metadata,story);
}

function renderMissionTimeline(){
 const agency=missionAgencyFilter.value;
 const target=missionTargetFilter.value;
 const category=missionCategoryFilter.value;
 visibleMissions=missions
  .filter(mission=>(agency==='all'||mission.agencyGroup===agency)&&(target==='all'||mission.target===target)&&(category==='all'||mission.category===category))
  .sort((a,b)=>a.year-b.year||a.name.localeCompare(b.name));
 missionResultCount.textContent=`${visibleMissions.length} ${visibleMissions.length===1?'event':'events'}${visibleMissions.length?` · ${visibleMissions[0].year}–${visibleMissions[visibleMissions.length-1].year}`:''}`;
 missionTimeline.replaceChildren();
 if(!visibleMissions.length){
  const empty=createMissionElement('li','mission-timeline-empty','No events match these filters. Try another combination or reset the filters.');
  missionTimeline.appendChild(empty);
  missionDetail.replaceChildren(createMissionElement('p','mission-detail-empty','Select a different filter combination to continue exploring the archive.'));
  selectedMissionId=null;
  return;
 }
 visibleMissions.forEach((mission,index)=>{
  const entry=createMissionElement('li','mission-timeline-entry');
  const button=createMissionElement('button','mission-event');
  button.type='button';
  button.dataset.missionId=mission.id;
  button.dataset.lane=index%2===0?'above':'below';
  button.setAttribute('aria-pressed','false');
  button.setAttribute('aria-label',`${mission.name}, ${mission.year}, ${mission.category==='mission'?'mission':'discovery'}, ${mission.targetLabel}`);
  const card=createMissionElement('span','mission-event-copy');
  card.append(
   createMissionElement('span','mission-event-year',String(mission.year)),
   createMissionElement('span','mission-event-kind',mission.category==='mission'?'MISSION':'DISCOVERY'),
   createMissionElement('span','mission-event-title',mission.name),
   createMissionElement('span','mission-event-agency',`${mission.agency} · ${mission.targetLabel}`)
  );
  button.append(card,createMissionElement('span','mission-event-marker',''));
  button.addEventListener('click',()=>selectMission(mission.id));
  entry.appendChild(button);
  missionTimeline.appendChild(entry);
 });
 const selected=visibleMissions.find(mission=>mission.id===selectedMissionId)||visibleMissions[0];
 selectMission(selected.id);
}

function selectMission(id){
 const mission=visibleMissions.find(item=>item.id===id);
 if(!mission)return;
 selectedMissionId=id;
 missionTimeline.querySelectorAll('.mission-event').forEach(button=>{
  const selected=button.dataset.missionId===id;
  button.classList.toggle('selected',selected);
  button.setAttribute('aria-pressed',String(selected));
 });
 renderMissionDetail(mission);
}

[missionAgencyFilter,missionTargetFilter,missionCategoryFilter].forEach(filter=>filter.addEventListener('change',renderMissionTimeline));
document.getElementById('missionReset').addEventListener('click',()=>{
 missionAgencyFilter.value='all';
 missionTargetFilter.value='all';
 missionCategoryFilter.value='all';
 renderMissionTimeline();
});
document.getElementById('missionFilters').addEventListener('submit',event=>event.preventDefault());
renderMissionTimeline();
const selectable=Object.keys(planets).filter(x=>x!=='Sun');['planetA','planetB'].forEach((id,idx)=>{const s=document.getElementById(id);s.innerHTML=selectable.map(n=>`<option ${n===(idx?'Mars':'Earth')?'selected':''}>${n}</option>`).join('');s.onchange=renderComparison});function renderComparison(){const a=planets[document.getElementById('planetA').value],b=planets[document.getElementById('planetB').value];const mk=(name,p)=>`<section class="compare-side"><h3>${name}</h3>${Object.entries(p.facts).map(([k,v])=>`<div class="compare-row"><span>${k}</span><strong>${v}</strong></div>`).join('')}</section>`;document.getElementById('comparison').innerHTML=mk(document.getElementById('planetA').value,a)+mk(document.getElementById('planetB').value,b)}renderComparison();
const quiz=[{q:'Which planet is known as the Red Planet?',a:['Venus','Mars','Mercury','Neptune'],correct:1},{q:'Which planet has the most famous ring system?',a:['Saturn','Earth','Jupiter','Uranus'],correct:0},{q:'What is the largest planet in our Solar System?',a:['Earth','Jupiter','Neptune','Saturn'],correct:1}];let qIndex=0,score=0;function renderQuiz(){const q=quiz[qIndex];document.getElementById('gamePanel').innerHTML=`<p class="eyebrow">QUESTION ${qIndex+1} OF ${quiz.length}</p><div class="quiz-q">${q.q}</div><div class="answer-list">${q.a.map((x,i)=>`<button class="answer" data-i="${i}">${x}</button>`).join('')}</div><div class="game-result" aria-live="polite"></div>`;document.querySelectorAll('.answer').forEach(b=>b.onclick=()=>{const ok=+b.dataset.i===q.correct;if(ok)score++;document.querySelector('.game-result').textContent=ok?'Correct. Nice orbit!':'Not quite — keep exploring.';document.querySelectorAll('.answer').forEach(x=>x.disabled=true);setTimeout(()=>{qIndex++;if(qIndex>=quiz.length){document.getElementById('gamePanel').innerHTML=`<p class="eyebrow">MISSION COMPLETE</p><div class="quiz-q">You scored ${score}/${quiz.length}.</div><button class="primary-btn" id="restartQuiz">Play again →</button>`;document.getElementById('restartQuiz').onclick=()=>{qIndex=0;score=0;renderQuiz()}}else renderQuiz()},900)})}function renderPuzzle(){const order=['Mercury','Venus','Earth','Mars','Jupiter','Saturn','Uranus','Neptune'];const shuffled=[...order].sort(()=>Math.random()-.5);let picked=[];document.getElementById('gamePanel').innerHTML=`<p class="eyebrow">ORBIT PUZZLE</p><div class="quiz-q">Place the planets in order from the Sun.</div><p class="puzzle-info">Tap planets in the sequence you believe is correct.</p><div class="puzzle-list">${shuffled.map(x=>`<button class="puzzle-chip">${x}</button>`).join('')}</div><div class="puzzle-slot">Your orbit sequence will appear here.</div>`;document.querySelectorAll('.puzzle-chip').forEach(btn=>btn.onclick=()=>{if(btn.classList.contains('selected'))return;picked.push(btn.textContent);btn.classList.add('selected');document.querySelector('.puzzle-slot').textContent=picked.join(' → ');if(picked.length===8){const ok=picked.every((x,i)=>x===order[i]);document.querySelector('.puzzle-info').textContent=ok?'Perfect! You know your cosmic neighbourhood.':'Almost — refresh the puzzle tab and try again.'}})}
renderQuiz();document.querySelectorAll('.game-tab').forEach(b=>b.onclick=()=>{document.querySelectorAll('.game-tab').forEach(x=>x.classList.remove('active'));b.classList.add('active');b.dataset.game==='quiz'?renderQuiz():renderPuzzle()});
let sound=false,ctx;document.getElementById('soundToggle').onclick=()=>{sound=!sound;if(sound){ctx=new (window.AudioContext||window.webkitAudioContext)();const o=ctx.createOscillator(),g=ctx.createGain();o.frequency.value=70;g.gain.value=.015;o.connect(g).connect(ctx.destination);o.start();setTimeout(()=>{o.stop();ctx.close()},350);document.getElementById('soundToggle').textContent='◉'}else document.getElementById('soundToggle').textContent='⌁'};
menuToggle.onclick=()=>setMobileMenuOpen(!menu.classList.contains('open'));
